Usando il file start.css prova a ricreare il layout fornito, usando grid e flexbox
Il primo elemento del blocco giallo è largo 3 volte rispetto i successivi
La colonna di sinistra è larga 1/4 rispetto la larghezza totale