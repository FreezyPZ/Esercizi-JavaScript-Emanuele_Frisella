Usando il file start.css prova a ricreare il layout fornito, usando grid
Il blocco green e orange sono alti la metà dei blocchi yellow e red