Crea un form di anagrafica per la registrazione ad un piattaforma.

Il form deve contenere i seguenti campi:
 - Email
 - Password
 - Nome e Cognome
 - Data di nascita
 - Numero di telefono
 - Selettore con scelta di un piano di abbonamento.
   - Un piano free
   - Un gruppo di massimo 3 piani con prezzo crescente
 - Un campo per scegliere se aggiungere o meno i vantaggi PRO
 - Campi per inserimento carta di scredito
   - Numero carta
   - CVC
   - Scadenza
 - Indirizzo di fatturazione
