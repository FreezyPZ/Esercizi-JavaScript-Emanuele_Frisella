Dato il form di partenza validare i campi tale che:
 - Tutti i campi siano obbligatori.
 - I campi relativi a numero carta di credito e CVC devono avere una prima validazione sulla lunghezza e la correttezza dei valori.
