Aggiungi all'`head` della pagina i tag per titolo, descrizione, autore, favicon e rispettive proprietà del protocollo Open Graph.
