Correggi lo snippet usando i rispettivi tag dove occorre.
